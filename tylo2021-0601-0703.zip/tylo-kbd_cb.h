#include <FL/names.h>
// the events activate, deactivate, hide, and show refer to visibility and useability of widgets (cells).
// events enter & leave only matter for drag and drop and other features i do not use

#define CASES_OTHER  case FL_RELEASE:  case FL_MOVE: case FL_ENTER:     case FL_LEAVE:       case FL_SHOW:     case FL_HIDE: \
                     case FL_KEYUP:    case FL_DRAG: case FL_ACTIVATE:  case FL_DEACTIVATE:  case FL_NO_EVENT
#define prtevent(s)  cout << s << ' ' << fl_eventnames[e] << " col " << cell->col << " row " << cell->row << endl

int Brdcell::handle(int e) {

   Brdcell *cell = this; 
   int k = Fl::event_key();
   int s = Fl::event_state();
   static int hilite = getiopt("cell_hi");
   Tbl *tbl = cur.tbl;
   static App *app = (App*) tbl->parent();

   if(s & FL_META)   return EVNOTHANDLED;
   
   switch(e) {
      case FL_SHORTCUT: return EVNOTHANDLED;    // return BRcell::handle(e);
      case FL_KEYBOARD:
         if(! (s & (FL_SHIFT | FL_CTRL | FL_ALT))) {

            alpha_s *dec = NULL, *inc = NULL;      // decls must occupy their own block in a switch() else compiler will complain

            // does the keystroke represent a tile? srch_keytab takes the int keystroke and returns a pointer to a struct containing (among other things)
            // the corresponding (possibly multibyte) symbol
            
            if(dec = srch_keytab(tbl->alpha, tbl->alphan, toupper(k))) {   // if match, decrement count for key entered
               inc = srch_keytab(tbl->alpha, tbl->alphan, cell->kystrk);   // and increment count for an overwrite, if any
               update_cnts(tbl, inc, dec);
               cell->kystrk = toupper(k);
               cell->copy_label(dec->vis);

               setmod(app, true);
              return EVHANDLED;
            }
            switch(k) {    // no match in keytab. if keystroke is delete, nothing is decremented, deleted keystroke is incremented
               
               case FL_Delete :  if(inc = srch_keytab(tbl->alpha, tbl->alphan, cell->kystrk)) {
                                    update_cnts(tbl, inc, NULL);
                                    cell->kystrk = FLLRCHR;             
                                    cell->copy_label(FLLRLBL);

                                    setmod(app, true);
                                 }
                                 return EVHANDLED;
               // everything hence is about focus and highlighting
               case FL_Tab    :  tbl->rck[0]->take_focus();                                                             return EVHANDLED;
               case FL_Right  :  if(cell->col < tbl->brdn - 1) tbl->brd[cell->row     ][cell->col + 1]->take_focus();   return EVHANDLED;
               case FL_Left   :  if(cell->col > 0)             tbl->brd[cell->row     ][cell->col - 1]->take_focus();   return EVHANDLED;
               case FL_Down   :  if(cell->row < tbl->brdn - 1) tbl->brd[cell->row + 1 ][cell->col    ]->take_focus();   return EVHANDLED;
                                 tbl->rck[0]->take_focus();                                                             return EVHANDLED;
               case FL_Up     :  if(cell->row > 0)             tbl->brd[cell->row - 1][cell->col    ]->take_focus();    return EVHANDLED;
               case FL_Home   :                                tbl->brd[tbl->brdn / 2][tbl->brdn / 2]->take_focus();    return EVHANDLED;
               default        :                                                                                         return EVNOTHANDLED; 
            }        // end switch(k)
         }           // end no mods
         if((s & FL_SHIFT) && ! (s & (FL_CTRL | FL_ALT))) {    // tab is the only valid shifted key for this handler
            if(k == FL_Tab) {
               app->brwsr->take_focus();
               return EVHANDLED;
            }
            return EVNOTHANDLED;
         }
         return EVNOTHANDLED; // end FL_KEYBOARD

      case FL_FOCUS:    cell->color(hilite);       cell->redraw();   return EVHANDLED;
      case FL_UNFOCUS:  cell->color(cell->lolite); cell->redraw();   return EVHANDLED;
      case FL_PUSH:     cell->take_focus();                          return EVHANDLED;
      CASES_OTHER:                                                   return EVNOTHANDLED;
      default: cout << "unprocessed event: "; prtevent("brd");       return EVNOTHANDLED;
   }        // end switch(e)
}
int Rckcell::handle(int e) {     // most everything in this handler is the same as above
                                 // except rck is 1-dimensional and the changing focus goes to different places
   Rckcell *cell = this;
   int k = Fl::event_key();
   int s = Fl::event_state();
   static int hilite = getiopt("cell_hi");
   static bool autor = getiopt("autoright");
   Tbl *tbl = cur.tbl;
   static App *app = (App*) tbl->parent();

   if(s & FL_META)   return EVNOTHANDLED;
   
   switch(e) {
      case FL_SHORTCUT: return EVNOTHANDLED;    // return BRcell::handle(e);
      case FL_KEYBOARD:
         if(! (s & (FL_SHIFT | FL_CTRL | FL_ALT))) {
            alpha_s *dec = NULL, *inc = NULL;

            if(dec = srch_keytab(tbl->alpha, tbl->alphan, toupper(k))) {   // RCK unmodifed alpha
               inc = srch_keytab(tbl->alpha, tbl->alphan, cell->kystrk);
               update_cnts(tbl, inc, dec);
               cell->kystrk = toupper(k);
               cell->copy_label(dec->vis);
               setmod(app, true);
               if(autor && cell->col + 1 < tbl->rckn) tbl->rck[cell->col + 1]->take_focus();
               return EVHANDLED;
            }                                                              // RCK unmodified nonalpha
            switch(k) {
               case FL_Delete    :  if(inc = srch_keytab(tbl->alpha, tbl->alphan, cell->kystrk)) {
                                       update_cnts(tbl, inc, NULL);
                                       cell->kystrk = FLLRCHR;             
                                       cell->copy_label(FLLRLBL);
                                       setmod(app, true);
                                    }
                                    return EVHANDLED;
               case FL_BackSpace :  {  int j = cell->col;
                                       if(j > 0) {
                                          j--;
                                          update_cnts(tbl, srch_keytab(tbl->alpha, tbl->alphan, tbl->rck[j]->kystrk), NULL);
                                          while(j < tbl->rckn - 1) {
                                             tbl->rck[j]->kystrk =   tbl->rck[j + 1]->kystrk;
                                             tbl->rck[j]->copy_label(tbl->rck[j + 1]->label());
                                             j++;
                                          }
                                          tbl->rck[j]->copy_label(FLLRLBL);
                                          tbl->rck[j]->kystrk = FLLRCHR;
                                          tbl->rck[cell->col - 1]->take_focus();
                                          setmod(app, true);
                                       }
                                    }
                                    return EVHANDLED;
               case FL_Down      :
               case FL_Tab       :                                tbl->notes              ->take_focus();   return EVHANDLED;
               case FL_Right     :  if(cell->col < tbl->rckn - 1) tbl->rck[cell->col + 1] ->take_focus();   return EVHANDLED;
               case FL_Left      :  if(cell->col > 0)             tbl->rck[cell->col - 1] ->take_focus();   return EVHANDLED;
               case FL_Home      :                                tbl->rck[0]             ->take_focus();   return EVHANDLED;
               case FL_End       :                                tbl->rck[tbl->rckn - 1] ->take_focus();   return EVHANDLED;
               case FL_Up        :  tbl->brd[tbl->brdn / 2][tbl->brdn / 2]                ->take_focus();   return EVHANDLED;
               default           :  return EVNOTHANDLED;
            }  // end switch(k)
         }     // end no mods
         if((s & FL_SHIFT) && ! (s & (FL_CTRL | FL_ALT))) {                // RCK shift+
            if(k == FL_Tab) {                                              // tab is the only valid shifted key
               tbl->brd[tbl->brdn / 2][tbl->brdn / 2]->take_focus();
               return EVHANDLED;
            }
            return EVNOTHANDLED;
         }
         return EVNOTHANDLED;    // end FL_KEYBOARD for RCK

      case FL_FOCUS:    cell->color(hilite);       cell->redraw();   return EVHANDLED;
      case FL_UNFOCUS:  cell->color(cell->lolite); cell->redraw();   return EVHANDLED;
      case FL_PUSH:     cell->take_focus();                          return EVHANDLED;
      CASES_OTHER:                                                   return EVNOTHANDLED;
      default: cout << "unprocessed event: "; prtevent("rck");       return EVNOTHANDLED;
   }                 // end switch(e)
}
