void menu_callback(Fl_Widget *w, void *v) {
   Appmenu *menu = (Appmenu *) w;
   App *app = (App*) v;
}
void rematch_mcb(MCB_ARGS) {

   MCBAPP_DECL;

   if(2 != fl_choice("This will overwrite the game.\nConfirm?", "No", 0, "Yes"))
      return;
   clear(app);                                        // clear board, rack, notes
   Brwsr *b = app->brwsr;
   time_t tm = time(NULL);                            // start time == now
   char tmstr[TIMESZ];
   strftime(tmstr, TIMESZ, TIMEFMT, localtime(&tm));
   cur.game->starttm.assign(tmstr);                   // set starttm; string endtm inits to 0 length
   if(cur.game->stat == GSOVER) {
      cur.game->stat = GSACTV;
      cur.nactv++;
   }
   mk_fmtd_text(cur.game);                            // assign formatted game id string to cur.game->fmtd
   b->text(b->value(), cur.game->fmtd.c_str());       // overwrite brwsr item text
   sort_brwsr(app, "");                               // sort will reselect already selected item
   ((Msg *) app->msg)->setmsg1();
}
void clear_mcb(MCB_ARGS) {
   if(2 == fl_choice("Confirm clear?", "No", 0, "Yes")) {
      MCBAPP_DECL;
      clear(app);
   }
   return;
}
void clear(App *app) {
   
   Tbl *tbl = cur.game->tbl;
   int j, k;
   
   for(j = 0; j < tbl->brdn; j++)
      for(k = 0; k < tbl->brdn; k++)
         if(tbl->brd[j][k]->kystrk != FLLRCHR) {
            update_cnts(tbl, srch_keytab(tbl->alpha, tbl->alphan, tbl->brd[j][k]->kystrk), NULL);
            tbl->brd[j][k]->label(FLLRLBL);
            tbl->brd[j][k]->kystrk = FLLRCHR;
         }
   for(j = 0; j < tbl->rckn; j++)
      if(tbl->rck[j]->kystrk != FLLRCHR) {
         update_cnts(tbl, srch_keytab(tbl->alpha, tbl->alphan, tbl->rck[j]->kystrk), NULL);
         tbl->rck[j]->label(FLLRLBL);
         tbl->rck[j]->kystrk = FLLRCHR;
      }
   cur.game->buffy->text(0);
   setmod(app, true);
}
void copyto_mcb(MCB_ARGS) {                  // copy either the rack or the bag to the clipboard, then save all games to disk, because why not?

   MCBMENU_DECL;                             // menu->text() tells me which object is source
   MCBAPP_DECL;                              // app is for save()
   Tbl *tbl = cur.tbl;                       // NB, some (all?) anagram websites set a limit on input length
   int j, k, n;   
   string clp_src;
   string clp_str;

   clp_src.assign(menu->text());
   cout << clp_src << " to clipboard" << endl;  

   if(! clp_src.compare("copy rack")) {      // loop thru rack, ignoring empty slots
   
      alpha_s *match;

      n = tbl->rckn;
      for(j = 0; j < n; j++) {
         if(tbl->rck[j]->kystrk == FLLRCHR)
            continue;
         if(match = srch_keytab(tbl->alpha, tbl->alphan, tbl->rck[j]->kystrk))   // find keystroke in keytab, append corresponding clip symbol
            clp_str += match->clp;
      }
   }
   else if(! clp_src.compare("copy bag")) {
      for(j = 0; j < tbl->alphan; j++) {     // loop thru every letter in bag and append remaining qt of that symbol to string
      
         int n = atoi(tbl->rem[tbl->alpha[j].bagrow]->label());

         for(k = 0; k < n; k++)
            clp_str += tbl->alpha[j].clp;
      }
   }
   else
      fl_alert("%s: internal error, invalid source", clp_src.c_str());     // clp_str.size() == 0 unless appended from a valid src
   Fl::copy(clp_str.c_str(), clp_str.size(), 1, Fl::clipboard_plain_text); // so no worries about Fl::copy()
   if(cur.mod) save(app);
}
void delete_mcb(MCB_ARGS) {      // delete a game from brwsr and vector<game_s*>

   if(2 != fl_choice("Confirm delete?", "No", 0, "Yes"))
      return;
      
   MCBAPP_DECL;

   Brwsr *b          = app->brwsr;
   int lnum             = b->value();
   vector<game_s*>& gms = app->games;              // needs to be a reference since vector potentially will be relocated
   game_s *gm           = cur.game;

   // without setting notes->buffer(0), delete gm->buffy causes these (harmless?) runtime errors:
   // Fl_Text_Buffer::remove_predelete_callback(): Can't find pre-delete CB to remove
   // Fl_Text_Buffer::remove_modify_callback(): Can't find modify CB to remove

   if(gm->stat == GSACTV)
      cur.nactv--;
   cur.ngames--;
   ((Msg *) app->msg)->setmsg1();
   b->remove(lnum);                                // clear the brwsr item. lnum == line number
   gms.erase(find(gms.begin(), gms.end(), gm));    // clear the pointer from the games vector and shrink the vector
   for(char *p: { gm->opp, gm->brd, gm->rck })     // clear the char* elements from the game_s
      delete p;
   cur.tbl->notes->buffer(0);                      // avoid error msgs
   delete gm->buffy;                               // delete the text buffer element   
   delete gm;                                      // a few elements not directly from operator new such as stat and timestamps

   if(lnum > b->size())                            // keep same line number highlighted unless it's out of bounds
      lnum = b->size();                      
   cur.tbl->hide();
   setmod(app, true);                              // set application modified status
   load_game((game_s *) b->data(lnum));
   b->select(lnum);                                // highlight item
}
void find_mcb(MCB_ARGS) {  // if(! (ltr = fl_input("Search for:")))
                           //    return;
}                          // call from menu will require a prompt, call from shortcut (will?may?) not
void find_symb(string symb) {

   static bool active = false;
   static int  clr = getiopt("find_hi");
   int         brdn = cur.tbl->brdn,
               rckn = cur.tbl->rckn,
               j, k, n = 0;

   if(active) {
      active = false;
      find_reset();  
   }
   else {
      for(j = 0; j < brdn; j++)
         for(k = 0; k < brdn; k++)
            if(! symb.compare(cur.tbl->brd[j][k]->label())) {
               cur.tbl->brd[j][k]->labelcolor(clr);
               cur.tbl->brd[j][k]->redraw();
               n++;
            }
      for(j = 0; j < rckn; j++)
         if(! symb.compare(cur.tbl->rck[j]->label())) {
            cur.tbl->rck[j]->labelcolor(clr);
            cur.tbl->rck[j]->redraw();
            n++;
         }
      if(n) active = true;
   }
}
void find_reset_mcb(MCB_ARGS) {  }     // reset from find_symb. reset color of all cells whether or not they were hilited

void find_reset() {
   static int clr = getiopt("cell_fg");
   cout << clr << endl;
   int brdn = cur.tbl->brdn;
   int rckn = cur.tbl->rckn;  
   int j, k;
   
   for(j = 0; j < brdn; j++)  for(k = 0; k < brdn; k++)  { cur.tbl->brd[j][k] ->labelcolor(clr); cur.tbl->brd[j][k]  ->redraw(); }
   for(j = 0; j < rckn; j++)                             { cur.tbl->rck[j]    ->labelcolor(clr); cur.tbl->rck[j]     ->redraw(); }
}
void game_over_mcb(MCB_ARGS) {      // to toggle or not to toggle? to toggle.

cout << "game over toggle" << endl;

   MCBAPP_DECL;
   game_s *gm  = cur.game;
   string cd;
   char tmstr[TIMESZ] = { '\0' };
         
   if(gm->stat == GSACTV) {
      cd = OVERCD;
      gm->stat = GSOVER;
      time_t tm = time(NULL);
      cur.nactv--;      
      strftime(tmstr, TIMESZ, TIMEFMT, localtime(&tm));        // there doesnt seem to be a string version of strftime
   }  
   else {
      // ask
      cd = ACTVCD;
      gm->stat = GSACTV;
      cur.nactv++;
   }
   gm->endtm.assign(tmstr);                                    // set or blank end timestamp
   gm->fmtd = cd + gm->opp + COLSEP + cd + gm->endtm;          // reformat menu item
   app->brwsr->text(app->brwsr->value(), gm->fmtd.c_str());    // display reformatted item

   setmod(app, true);                                          // set appl modified status
   sort_brwsr(app, "");
   ((Msg *) app->msg)->setmsg1();
}
void new_mcb(MCB_ARGS) { MCBMENU_DECL; MCBAPP_DECL; new_game(menu, app, true); } // need wrapper so rematch can use same function without asking for opp name
void new_game(MCB_ARGS, bool ask) {
cout << "new gm" << endl;
   MCBAPP_DECL;
   MCBMENU_DECL;
   Tbl *tbl;
   char *opp;
   int opplen, j;
   vector<game_s*>& games = app->games;                  // needs to be a reference since the whole vector may move

   if(ask) {
   
      Tbl **tbls = app->tbls;

      for(j = 0; j < cur.ntbls; j++)                     // find the ptr to the table
         if(! strcmp(menu->text(), tbls[j]->name))
            break;
      if(j == cur.ntbls) {
         fl_alert("table %s not found.", menu->text());  // should never happen
         return;
      }
      while(true) {
         if(! (opp = (char *) fl_input("Please enter the opponent's name.")))
            return;
         opplen = strlen(opp);
         if(opplen >= OPPMAX)
            fl_alert("That name is too long, please try again.");
         else
            break;
      }
      tbl = tbls[j];
   }
   else {
      tbl = cur.tbl;
      opp = cur.game->opp;
      opplen = strlen(opp);
   } 
   unload_game(true);            // write about-to-be-hidden game back to memory

   game_s *game;
   if(! (game = new nt game_s))
      EOOM("new game");
   game->tbl = tbl;                                            // fill in new game data: game's pointer to its tbl
   game->stat = GSACTV;                                        // game new status == active
   if(! (game->brd = new nt char[tbl->brdn * tbl->brdn]()))
      EOOM("board");
   if(! (game->rck = new nt char[tbl->rckn]()))
      EOOM("rack");
   if(! (game->opp = new nt char[opplen + 1]()))
      EOOM("opponent name");
   if(! (game->buffy = new nt Fl_Text_Buffer))
      EOOM("text buffer");
   strcpy(game->opp, opp);
   time_t tm = time(NULL);                                     // start time == now
   char tmstr[TIMESZ];
   strftime(tmstr, TIMESZ, TIMEFMT, localtime(&tm));
   game->starttm.assign(tmstr);                                // set starttm; string endtm inits to 0 length
   mk_fmtd_text(game);                                         // create formatted string for brwsr
   games.push_back(game);                                      // games is a vector of pointers to game structs
   cur.ngames++;
   cur.nactv++;
   ((Msg *) app->msg)->setmsg1();
   app->brwsr->add(game->fmtd.c_str(), game);                  // add formatted game id and game ptr to browser
   app->brwsr->select(cur.ngames, 1);                          // select here so sort_brwsr() will reselect properly
   sort_brwsr(app, "");                                        // sort the items
   cur.tbl->hide();                                            // hide in case new game is different tbl
   load_game(game);                                            // load_game() will unhide appropriate tbl
   cur.tbl->brd[cur.tbl->brdn / 2][cur.tbl->brdn / 2]->take_focus();
}
void quit_mcb(MCB_ARGS) {     // write all game structs back to disk

   MCBAPP_DECL;

   if(cur.mod) {  
      switch(fl_choice("You are about to exit. Do you want to save first?", "No", "Yes", "Don't exit")) {
         case 2: return;
         case 1: save(app);   // fallthru
         case 0: quit(app);
      }
   }
   else quit(app);
}
void quit(App *app) {      // always write out the options
   write_opts(app);
   app->hide();
}
void rename_mcb(MCB_ARGS) {                              // rename opponent -- untested

   MCBAPP_DECL;

   Brwsr *br   = app->brwsr;
   int lnum    = br->value();
   game_s *gm  = cur.game;
   cc *rsp;
   
   while(1) {
      if(! (rsp = fl_input("Please enter the new name.")))
         return;

      if(strlen(rsp) >= OPPMAX)
         fl_alert("That name is too long, please try again.");
      else
         break;
   }
   mk_fmtd_text(gm);
   br->text(lnum, gm->fmtd.c_str());
   sort_brwsr(app, "");
}
void check_isreg(const char *path) {
   #ifdef HAVEFS
      if(! std::filesystem::is_regular_file(std::filesystem::status(path))) {
         fl_alert("%s is not a regular file - can't continue.", path);
         exit(EXIT_FAILURE);        
      }
   #endif
   return;
}
void save_mcb(MCB_ARGS) {  MCBAPP_DECL; save(app); }
void save(App *app) {

   game_s   *gm;
   int      j, k, ntslen;
   char     c;

   if(cur.mod == false) return;
   unload_game(false);
   check_isreg(GAMEFL);       // can abort
   unlink(GAMEFL ".bak");
   if(rename(GAMEFL, GAMEFL ".bak")) {
      fl_alert("Could not make a backup of " GAMEFL ".");
      // do you want to ...
   }
   fstream gmfs(GAMEFL, std::ios::out | std::ios::trunc);
   if(! gmfs)
      cout << "open game file for writing failed" << endl;
   else {
      for(j = 1; j <= app->brwsr->size(); j++) {      // save in brwsr order so that sorting during next init is unnecessary
      
         gm = (game_s *) app->brwsr->data(j);         // cout << "write " << gm << ' ' << gm->opp << ' ' << gm->starttm << endl;
         ntslen = gm->buffy->length();
         if(ntslen > NTSMAX) {
            fl_alert("Truncating notes for %s %s at the maximum of %d characters", gm->opp, gm->starttm.c_str(), NTSMAX);
            ntslen = NTSMAX;
         }
         gmfs     << gm->stat       // no delim
                  << gm->tbl->name  << '|'
                  << gm->opp        << '|'
                  << gm->starttm    << '|'
                  << gm->endtm      << '|';
               
         for(k = 0; k < gm->tbl->rckn; k++)
            gmfs  << gm->rck[k];
         gmfs                       << '|';
            
         for(k = 0; k < gm->tbl->brdn * gm->tbl->brdn; k++)
            gmfs  << gm->brd[k];
         gmfs                       << '|'
                  << ntslen         << '|';

         char *nts = gm->buffy->text();

         for(k = 0; k < ntslen; k++)
            gmfs  << (nts[k] != '\n' ? nts[k] : NTSNL);     // write notes, xlating embedded newlines
         gmfs     << '\n';
         free(nts);
      }
      gmfs.close();
      cout << j - 1 << " games written" << endl;
      setmod(app, false);
   }
   cur.tbl->show();                    // undoes hide() in unload_game() near top of function
}
void sort_mcb(MCB_ARGS) {
   MCBMENU_DECL; MCBAPP_DECL;
   sort_brwsr(app, (string) menu->text());
}

void sort_brwsr(App *app, string order) {
   
   // the vector is the source of the sort because that avoids creating a new vector and copying out and deparsing the format codes from
   // the about-to-be rearranged brwsr items.

   Brwsr *b = app->brwsr;
   vector<game_s*> gms = app->games;
   
   if(order.empty())             // calls to this func initiated by code will usually have empty order in which case use value from lastsort property
      order = b->lastsort;       // otoh, calls made by user from menu will necessarily indicate the order desired and order will be written to the property
   else
      b->lastsort = order;

   cout << "sort, order=" << order << endl;
   
   bool (*funcs[4])(game_s *g1, game_s *g2) = { by_name, by_start, by_end, by_stat_by_name };
   int which = order[0] - '1';

   if(0 <= which && which < sizeof(funcs) / sizeof(funcs[0])) {

      void *resel = b->data(b->value());                 // remember game address of selected item
cout << resel << " save selected address" << endl;

      sort(gms.begin(), gms.end(), funcs[which]);

      cc *statfmt;                                       // write sorted games back to menu
      for(int j = 0; j < gms.size(); j++) {
         statfmt = (gms[j]->stat == GSACTV ? ACTVCD : OVERCD);
         b->text(j + 1, ((string) statfmt + gms[j]->opp + COLSEP + statfmt + gms[j]->starttm).c_str());
         b->data(j + 1, gms[j]);
         if(gms[j] == resel) {                              // found the game address - rehighlight previously selected item
            b->select(j + 1, 1);
cout << gms[j] << " found previously selected address" << endl;
         }
      }        
      setmod(app, true);
   }
   else
      fl_alert("Ignoring invalid sort order \"%s\"", order.c_str());
}
bool by_name(game_s *g1, game_s *g2) {
   int cmp = strcmp(g1->opp, g2->opp);
   return cmp < 0 ? true : (cmp ? false : (g1->starttm.compare(g2->starttm) < 0));
}
bool by_start(game_s *g1, game_s *g2) {
   return g1->starttm.compare(g2->starttm) < 0;
}
bool by_end(game_s *g1, game_s *g2) {
   return g1->endtm.compare(g2->endtm) < 0;
}
bool by_stat_by_name(game_s *g1, game_s *g2) {

   int cmp = g1->stat - g2->stat;

   if(cmp == 0) {
      cmp = strcmp(g1->opp, g2->opp);
      if(cmp == 0)
         cmp = g1->starttm.compare(g2->starttm);      // also sort by time -- there can be multiple (in)active games for the same opp
   }
   return cmp < 0;
}
void squish_mcb(MCB_ARGS) {            // move rck letters left until there are no empty spots and set focus to rck % number of nonempty spots

   Rckcell **rck = cur.tbl->rck; 
   int j, k = 0, n = cur.tbl->rckn;

   for (j = 0; j < n; j++)
      if(strcmp(rck[j]->label(), FLLRLBL)) {
         rck[k]->kystrk = rck[j]->kystrk;
         rck[k++]->copy_label(rck[j]->label());
      }
   rck[k % n]->take_focus();
   while(k < n) {
      rck[k]->kystrk = FLLRCHR;
      rck[k++]->copy_label(FLLRLBL);
   }        
}
void  help_mcb       (MCB_ARGS){}

void  cstm_mcb(MCB_ARGS) {

   static Fl_Window *miscwin = NULL;
   
   if(! miscwin) {

      MCBAPP_DECL;
   
      miscwin = new Fl_Window(app->x(), app->y(), app->w(), app->h());
      Fl_Text_Editor *miscte = new Fl_Text_Editor(0, 0, app->w(), app->h());
      miscte->wrap_mode(Fl_Text_Display::WRAP_AT_BOUNDS, 0);
      Fl_Text_Buffer *buff = new Fl_Text_Buffer();
      miscte->buffer(buff);
      buff->appendfile(CSTMFL, 4*1024*1024);
   }
   miscwin->show();
}

