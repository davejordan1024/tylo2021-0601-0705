class Tbl : public Fl_Group {    // class Tbl is composed of a board, a rack, 2 progress indicators, 4 columns describing the bag and number of
                                 // vowels/cons remaining, a text editor, and a map between keystrokes and displayed symbols

   #define TBLALRT(msg)       fl_alert(msg ", %s, %s.", TMPLTFL, name)
   #define SYMALRT(msg, num)  fl_alert(msg ", %s, %s, symbol #%d.", TMPLTFL, name, num)

   // Fl_Text_Editor *notes, below, is instantiated once per table since the tables may have different layouts. The TEs will get a buffer when games are read
   // from disk (read_games()), when user selects a game (load_game()), and when new_game occurs (new_game() calls load game()). Thus the TE's buffer will be
   // swapped around as needed. The game struct has space for a pointer to a buffer which is assigned a new buffer in read_games() and new_game(). The text
   // contents of the buffer is filled by read_games() if anything is on disk, and of course by the user when they type anything into it.

   public:

   Brdcell           ***brd;
   Rckcell           **rck;
   Numcell           *oppcnt, *bagcnt;
   Bagrow            **bagrows;
   Bagcell           **vis, **pv, **rem, **gvn, *vwllbl, *vwlcnt, *cnslbl, *cnscnt, *tilelbl, *tilecnt;
   Notes             *notes;
   game_s            *game;
   alpha_s           *alpha;
   int               brdn, rckn, *clrs, alphan, alphacn = 0, alphavn = 0, alphatn = 0;
   char              *name;

   ~Tbl(){};
   Tbl(int tblx, int tbly, int tblw, int tblh, int brdbig, tblinfo_s ti) : Fl_Group(tblx, tbly, tblw, tblh) {

      // ctor part 1: some table specs are already parsed from tmplt file into above arg tblinfo_s *ti.
      // they need sanity check and also i will parse and check the rest of the specs which remain in the misc member of same struct.
      // this 1st part is all about storing non-UI data/objects in heap memory. actual widgets are created in step 2.
      
      cout << "create " << ti.name << endl;

      begin();
      hide();        // it is not enough to show() the desired table, all others must be hidden

      box(FL_FLAT_BOX);
      color(getiopt("tbl_bg"));  //color(FL_RED);
      
      char *tok, *misc;
      int j;
                                                            // begin with data already stored in variable ti by read_game_info()
      if(! (name = new nt char[ti.name.length() + 1]()))    // ->name cant be empty since getline would have returned -1
         EOOM("table name");
      strcpy(name, (char *) ti.name.c_str());
      
      if(ti.brdn < 3 || ti.brdn > BRDMAX) {                 // MEM: brd size
         TBLALRT("Board size invalid");
         return;
      }
      if(ti.rckn < 1 || ti.rckn > RCKMAX) {                 // MEM: rck size
         TBLALRT("Rack size invalid");
         return;
      }
      if(ti.alphan < 1 || ti.alphan > ALPHAMAX) {           // MEM: alphabet size. includes blank tile if applicable
         TBLALRT("Alphabet size invalid");
         return;
      }
      brdn = ti.brdn;                                       // shortcut vars since these will be referenced a lot
      rckn = ti.rckn;
      alphan = ti.alphan;

      if(! (alpha = new nt alpha_s[alphan]))                // MEM: a struct for each symbol in the template
         EOOM("alpha struct");
      misc = (char *) ti.misc.c_str();                      // REMAINDER of table specs are still lumped together in ti.misc.

      for(j = 0; j < alphan; j++) {                         // MEM: parse symbol specs.
      
         alpha[j].bagrow = j;                               // the bagrows are going to be displayed in order encountered here while reading file,
                                                            // but then sorted by keystroke for srch_keytab().
         if(j)
            tok = strtok(NULL, "|");                           // MEM: must pass NULL to strtok on iterations after first
         else
            tok = strtok(misc, "|");
         if(! tok) {
            TBLALRT("End of line instead of keystroke");       // MEM: keystroke will be compared to the int reported by Fl::event_key()
            return;
         }
         if(tok[1]) {
            SYMALRT("Invalid keystroke length", j);
            return;
         }
         alpha[j].kystrk = *tok;

         if(! (tok = strtok(NULL, "|"))) {
            TBLALRT("End of line instead of clipboard symbol");   // MEM: clipboard symbol mostly for pasting representation of blank tile
            return;                                               // but all keystrokes could also have somthing different
         }
         if(! (alpha[j].clp = new nt char[strlen(tok) + 1]()))
            EOOM("clipboard symbol");
         strcpy(alpha[j].clp, tok);

         if(! (tok = strtok(NULL, "|"))) {
            TBLALRT("End of line instead of bag symbol");         // MEM: bag area column 1. bag symbol will appear oncreen during gameplay.
            return;
         }
         if(! (alpha[j].vis = new nt char[strlen(tok) + 1]()))
            EOOM("bag symbol");
         strcpy(alpha[j].vis, tok);
         
         if(! (tok = strtok(NULL, "|"))) {
            TBLALRT("End of line instead of point value");        // MEM: col 2. point value
            return;
         }
         if(! isdigit(tok[0])) {
            SYMALRT("Point value is not a digit", j);
            return;
         }
         if(tok[1])
            if(! isdigit(tok[1])) {
               SYMALRT("Point value contains nondigit", j);
               return;
            }
            else if(tok[2]) {
               SYMALRT("Point value > 99", j);
               return;
            }
         alpha[j].pointv = atoi(tok);
                                                                  // MEM: col 3, remaining qt, is not parsed here and is not stored in the game file
         if(! (tok = strtok(NULL, "|"))) {                        // MEM: col 4. qt given at start of game
            TBLALRT("End of line instead of given quantity");
            return;
         }
         if(! isdigit(tok[0])) {
            SYMALRT("Given quantity is not a digit", j);
            return;
         }
         if(tok[1])
            if(! isdigit(tok[1])) {
               SYMALRT("Given quantity contains nondigit", j);
               return;
            }
            else if(tok[2]) {
               SYMALRT("Given quantity > 99", j);
               return;
            }
         alpha[j].given = atoi(tok);                           
         alphatn += alpha[j].given;                            // MEM: total number of tiles for this table

         switch (alpha[j].isvwl = strtok(NULL, "|")[0]) {      // MEM: alpha[j] is the alpha_s for the table
            case '0':   alphacn += alpha[j].given; break;      // MEM: alphacn, vn, & tn are the totals for the table under the bag display
            case '1':   alphavn += alpha[j].given; break;
            case '2':   alphacn += alpha[j].given;
                        alphavn += alpha[j].given; break;
            case '\0':  { TBLALRT("End of line instead of vowel/cons. indicator");  return; }
            default:    { SYMALRT("Invalid vowel/consonant indicator", j);          return; }
         }
      }  // bottom of alpha loop

      // colors. single char codes may be specified in the template file. if there arent any, assume user wants nothing. otherwise get list
      // of "multiplier" options from options file, look up specified char in list for a real color int. multiplier color options are notional;
      // they could all be defined as chartreuse for all the logic cares. The static struct is for minimizing calls to getiopt.

      if(! (tok = strtok(NULL, "|")))                                      // MEM: no colors requested
         clrs = nullptr;
      else {
         int nclrs = brdn * brdn;

         if(! (clrs = new nt int[nclrs]()))                                // MEM: space for an array of colors, 1 elem per board cell
            EOOM("color array");

         static struct clr_s {                                             // MEM: make temp storage for getiopt ret values
            int      dl = getiopt("clr_dl"),    tl = getiopt("clr_tl"),    // MEM: double, triple letter
                     dw = getiopt("clr_dw"),    tw = getiopt("clr_tw"),    // MEM: double, triple word
                     bg = getiopt("app_bg"),    nm = getiopt("clr_nm");    // MEM: app background color is specified by any char that is not otherwise defined
         } clrdefs;                                                        // MEM: nm means no multiplier. a catchall if needed.

         bool stop = false;
         
         for(j = 0; j < nclrs; j++) {
            switch(tok[j]) {                                               // MEM: no newlines, courtesy of read_table_info()

               case '.'    :  clrs[j]  = clrdefs.nm;  break;
               case 'd'    :  clrs[j]  = clrdefs.dl;  break;
               case 't'    :  clrs[j]  = clrdefs.tl;  break;
               case 'D'    :  clrs[j]  = clrdefs.dw;  break;
               case 'T'    :  clrs[j]  = clrdefs.tw;  break;
               case '\0'   :  stop = true;            break;
               default     :  clrs[j]  = clrdefs.bg;  break;
            }
            if(stop) {
               fl_alert("Number of colors is less than board size, template %s", name);
               break;
            }
         }
         if(tok[j])
            fl_alert("Number of colors is greater than board size, template %s", name);
      }     // end else-has-colors block

      // ctor part 2: create and place UI widgets ========================================================================================

      int   pad      = getiopt("pad"),
            cellpix  = getiopt("cellpix");

      {  int   x = tblx + pad +  (brdbig - brdn) / 2 * cellpix,            // UI: board - this mess should cause it to be centered in the allotted area
               y = tbly +        (brdbig - brdn) / 2 * cellpix,
               k;
         if(! (brd = new nt Brdcell**[brdn]))
            EOOM("board");
         for(j = 0; j < brdn; j++) {
            if(! (brd[j] = new nt Brdcell*[brdn]))
               EOOM("board row");
            for(k = 0; k < brdn; k++)
               if(! (brd[j][k] = new nt Brdcell(cellpix, x, y, j, k)))
                  EOOM("board cell");
         }
         if(clrs) {
            for(j = 0; j < brdn; j++)
               for(k = 0; k < brdn; k++) {
                  brd[j][k]->color(clrs[j * brdn + k]);
                  brd[j][k]->lolite = clrs[j * brdn + k];
               }
            delete [] clrs;
         }
      }                                                                    // UI: progress indicators (opp and bag cnts)
      {  int   x = brd[0][0]->x(),
               y = brd[brdn - 1][0]->y() + brd[brdn - 1][0]->h() + pad,
               w = brdn * cellpix;

         if(! (oppcnt = new nt Numcell(x,                y, w * 3/4, cellpix, "opp")))
            EOOM("opponent status");
         if(! (bagcnt = new nt Numcell(x + oppcnt->w(),  y, w * 1/4, cellpix, "bag")))
            EOOM("bag status");
         bagcnt->align(FL_ALIGN_RIGHT | FL_ALIGN_INSIDE);
      }
                                                                                    // UI:   rack - in terms of a printed page, the centering formula is
      {  int   x = brd[0][0]->x()   +   (brdn * cellpix   -   rckn * cellpix) / 2,  //       x coord = left_margin + (page_width - text_width) / 2
               y = bagcnt->y() + bagcnt->h() + pad;
               
         if(! (rck = new nt Rckcell*[rckn]))
            EOOM("rack");
         for(j = 0; j < rckn; j++)
            if(! (rck[j] = new nt Rckcell(x + (j * cellpix), y, cellpix, j)))
               EOOM("rack cell");
      }
      {  int   x = tblx + pad,                                                      // UI: notes
               y = rck[0]->y() + rck[0]->h() + pad,
               w = brdbig * cellpix,
               h = this->y() + this->h() - y;

         if(! (notes = new nt Notes(x, y, w, h)))
            EOOM("text editor");
      }
      {  const int   tab1 = tblx + pad + brdbig * cellpix + 2 * pad,                // UI: bag
                     tab2 = tab1 + VISPIX,
                     tab3 = tab2 + PVPIX,
                     tab4 = tab3 + REMPIX;
         int y = tbly;
         Bagcell **bagmem;
         
         bagrows = new nt Bagrow*[alphan];
         
         char lbl[4];

         if(! (bagmem = new nt Bagcell*[4 * alphan]))
            EOOM("bag cells");
         vis   = bagmem;
         pv    = bagmem + 1 * alphan;
         rem   = bagmem + 2 * alphan;
         gvn   = bagmem + 3 * alphan;

         for(j = 0; j < alphan; j++) {
         
            // class Bagrow instances contain only the string for the symbol of the row and a handler which calls find_symb to highlight the symbol
            // everywhere on the table. class Bagrow does not contain any child widgets. class Bagrow and its instances are not to be confused with
            // struct alpha_s member bagrow
            
            if(! (   bagrows[j]  = new nt Bagrow(tab1,   y, tab4 + GVNPIX,    cellpix, alpha[j].vis)))
                     EOOM("bag rows");
         
            // these widgets are the row components which, to repeat, are not contained by Bagrow instances

            if(! (   (vis[j]     = new nt Bagcell(tab1,  y,          VISPIX,  cellpix, 22, FL_ALIGN_RIGHT,  0)) &&
                     (pv[j]      = new nt Bagcell(tab2,  y + PVVPIX, PVPIX,   cellpix, 14, FL_ALIGN_LEFT,   0)) &&
                     (rem[j]     = new nt Bagcell(tab3,  y,          REMPIX,  cellpix, 18, FL_ALIGN_RIGHT,  0)) &&
                     (gvn[j]     = new nt Bagcell(tab4,  y,          GVNPIX,  cellpix, 18, FL_ALIGN_LEFT,   0))
            ))
                     EOOM("bag row components");
            
            vis[j]->label(alpha[j].vis);
            sprintf(lbl, "%d", alpha[j].pointv);
            pv[j]->copy_label(lbl);
            sprintf(lbl, "/%d", alpha[j].given);         // given == "/nn"
            rem[j]->copy_label(lbl + 1);                 // rem is as above without slash
            gvn[j]->copy_label(lbl);
            
            y += cellpix;
         }
         qsort(alpha, alphan, sizeof(alpha_s), qcmp);    // sort alpha by keystroke for lookup now that it has been laid out in user order
         
         // bag totals *******************************************************************************************************
         {  y += pad;
            if(! (
               (cnslbl =   new nt Bagcell(tab1, y,             cellpix * 2, cellpix, 14, FL_ALIGN_LEFT, "cons"          )  ) &&
               (cnscnt =   new nt Bagcell(tab4, y,             cellpix + 3, cellpix, 14, FL_ALIGN_RIGHT, I2CS(alphacn)  )  ) &&
               (vwllbl =   new nt Bagcell(tab1, y += cellpix,  cellpix * 2, cellpix, 14, FL_ALIGN_LEFT, "vowel"         )  ) &&
               (vwlcnt =   new nt Bagcell(tab4, y,             cellpix + 3, cellpix, 14, FL_ALIGN_RIGHT, I2CS(alphavn)  )  ) &&
               (tilelbl =  new nt Bagcell(tab1, y += cellpix,  cellpix * 2, cellpix, 14, FL_ALIGN_LEFT, "tiles"         )  ) &&
               (tilecnt =  new nt Bagcell(tab4, y,             cellpix + 3, cellpix, 14, FL_ALIGN_RIGHT, I2CS(alphatn)  )  )
            ))
               EOOM("bag totals");
         }
      }
      end();
      cur.ntbls++;
   }                    // end ctor
};
